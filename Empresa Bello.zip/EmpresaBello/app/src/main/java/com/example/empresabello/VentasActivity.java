package com.example.empresabello;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class VentasActivity extends AppCompatActivity implements Response.ErrorListener, Response.Listener<JSONObject> {

    EditText jetCodVenta, jetUsuarioVenta, jetFechaVenta, jetNombreUsrVenta,jetNombreComprador;
    TextView jtvRefMoto, jtvDescMoto, jtvValorMoto,jtvSeleccionMoto,jtvWelcomeName;
    CheckBox jcbActivoVenta;
    String spinnerText, url, usrMoto, nameMoto, usrComprador, codFactura, fechaFactura, refMoto, descMoto, valorMoto,cbActivoVenta, userName,moto;
    Spinner menuMotos;
    RequestQueue rq;
    JsonRequest jrq;
    ImageView imgPortada;
    RequestQueue requestQueue;
    Button btngomoto, btnReactivarVenta, btnBuscarFactura;
    byte sw, cap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventas);

        Objects.requireNonNull(getSupportActionBar()).hide();

        jetCodVenta = findViewById(R.id.etCodFactura);
        jetUsuarioVenta = findViewById(R.id.etCodUsuario);
        jetFechaVenta = findViewById(R.id.etFechaFactura);
        jetNombreUsrVenta = findViewById(R.id.etNombreUsrVenta);
        jetNombreComprador = findViewById(R.id.etNombreComprador);
        jtvRefMoto = findViewById(R.id.tvRefMoto);
        jtvDescMoto = findViewById(R.id.tvDesMoto);
        jtvValorMoto = findViewById(R.id.tvValorMoto);
        jcbActivoVenta = findViewById(R.id.cbActivoMoto);
        jtvSeleccionMoto = findViewById(R.id.tvSeleccionMoto);
        jtvWelcomeName = findViewById(R.id.tvWelcomeName);

        btnBuscarFactura = findViewById(R.id.btnFactura);

        btngomoto = findViewById(R.id.btnGoMoto);
        userName = getIntent().getStringExtra("userName");
        jtvWelcomeName.setText("¡Hola " + userName + "!");

        imgPortada= findViewById(R.id.imgVentaMoto);

        menuMotos = findViewById(R.id.spMenuMotos);
        ArrayAdapter <CharSequence> adapter=ArrayAdapter.createFromResource(this, R.array.Motocicletas, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        menuMotos.setAdapter(adapter);

        btnReactivarVenta = findViewById(R.id.btnAnularVenta);
        btnReactivarVenta.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                codFactura = jetCodVenta.getText().toString();
                if(codFactura.isEmpty()){
                    cap = 1;
                    Toast.makeText(VentasActivity.this, "Debes un ingresar un código de factura", Toast.LENGTH_SHORT).show();
                    jetCodVenta.requestFocus();
                }else{
                    cap = 2;
                    url = "Http://192.168.1.15:80/WebServices/reactivarfact.php";
                }

                StringRequest postRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (cap == 2) {
                            LimpiarMoto();
                            Toast.makeText(getApplicationContext(), "Factura reactivada!", Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if(cap == 2){
                            Toast.makeText(getApplicationContext(), "Error reactivando factura!", Toast.LENGTH_LONG).show();
                        }
                    }
                }){
                    @Override
                    protected Map<String, String> getParams()
                    {Map<String, String> params = new HashMap<>();
                        params.put("codfactura",codFactura.trim());
                        return params;
                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(VentasActivity.this);
                requestQueue.add(postRequest);

                return true;
            }
        });

        rq = Volley.newRequestQueue(this);

    }
    /*Boton Buscar Moto*/
    public void GoMoto(View view) {
        spinnerText = menuMotos.getSelectedItem().toString();

        switch (spinnerText) {
            case "--":
                Toast.makeText(this, "Seleccione una referencia por favor", Toast.LENGTH_SHORT).show();
                imgPortada.setImageResource(R.drawable.motorbike_animated);
                jtvSeleccionMoto.setText("Escoja la motocicleta Honda:");
                jtvRefMoto.setText("");
                jtvDescMoto.setText("");
                jtvValorMoto.setText("");
                break;

            case "CB 150R":
                imgPortada.setImageResource(R.drawable.honda_cb150r);
                jtvRefMoto.setText("HCB150R CEM_15");
                jtvDescMoto.setText("16.1 HP @ 9500 rpm");
                jtvValorMoto.setText("11400000");
                break;

            case "CB 300R":
                imgPortada.setImageResource(R.drawable.honda_cb300r);
                jtvRefMoto.setText("HCB300R CEM_30");
                jtvDescMoto.setText("30.7 HP @ 9000 rpm");
                jtvValorMoto.setText("26700000");
                break;

            case "CB 650R":
                imgPortada.setImageResource(R.drawable.honda_cb650r);
                jtvRefMoto.setText("HCB650R CEM_65");
                jtvDescMoto.setText("95 HP @ 12000 rpm");
                jtvValorMoto.setText("42600000");
                break;

            case "CB 1000R":
                imgPortada.setImageResource(R.drawable.honda_cb1000r);
                jtvRefMoto.setText("HCB1000R CEM_100");
                jtvDescMoto.setText("140 HP @ 8500 rpm");
                jtvValorMoto.setText("74800000");
                break;
        }

        if (!spinnerText.equals("--")) {
            jtvSeleccionMoto.setText(String.format("Esta es tu Honda ⬆️ %s", spinnerText));
            Toast.makeText(this, String.format("Escogiste la Honda %s!", spinnerText), Toast.LENGTH_SHORT).show();
        }
    }

    /*Boton Verificar Factura Existente*/
    public void VerificarFactura(View view){
        codFactura = jetCodVenta.getText().toString();
        if (codFactura.isEmpty()){
            Toast.makeText(this, "Es necesario ingresar un código de factura", Toast.LENGTH_SHORT).show();
            jetCodVenta.requestFocus();
        }else{
            url = "Http://192.168.1.15:80/WebServices/consultaCodFact.php?codfactura="+codFactura;
        }

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Toast.makeText(VentasActivity.this, "Ya existe una factura, por favor ingrese un código diferente para una nueva o consulte la factura existente", Toast.LENGTH_LONG).show();
                sw = 1;
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(VentasActivity.this, "No hay facturas asociadas al código proporcionado. ¡Puede Continuar!", Toast.LENGTH_LONG).show();
                sw = 0;
            }
        }
        );
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    /*Boton Buscar Usuario*/
    public void BuscarVendedor(View view){
        usrMoto = jetUsuarioVenta.getText().toString().trim();
        if (usrMoto.isEmpty()){
            Toast.makeText(this, "Es necesario ingresar un código de vendedor", Toast.LENGTH_SHORT).show();
            jetUsuarioVenta.requestFocus();
        }else {
            url = "Http://192.168.1.15:80/WebServices/consultaVendedor.php?usr=" + usrMoto;


            JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    Toast.makeText(VentasActivity.this, "Vendedor registrado", Toast.LENGTH_SHORT).show();
                    JSONObject jsonObject;
                    try {
                        jsonObject = response.getJSONObject(0);//posicion 0 del arreglo....
                        jetNombreUsrVenta.setText(jsonObject.optString("nombre") + " Asesor #" + jsonObject.optString("registro"));
                    } catch (JSONException e) {
                        Toast.makeText(VentasActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(VentasActivity.this, "No existe ningún vendedor registrado con el código ingresado", Toast.LENGTH_LONG).show();
                    jetNombreUsrVenta.setText("");
                    jetUsuarioVenta.requestFocus();
                }
            }
            );
            requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(jsonArrayRequest);
        }
    }

    /*Guardar Factura Completa*/
    public void GuardarFactura(View view){
        codFactura = jetCodVenta.getText().toString().trim();
        fechaFactura = jetFechaVenta.getText().toString().trim();
        userName = jetUsuarioVenta.getText().toString().trim();
        usrMoto = jetNombreUsrVenta.getText().toString().trim();
        usrComprador = jetNombreComprador.getText().toString().trim();
        moto = menuMotos.getSelectedItem().toString().trim().trim();
        refMoto = jtvRefMoto.getText().toString().trim();
        descMoto = jtvDescMoto.getText().toString().trim();
        valorMoto = jtvValorMoto.getText().toString().trim();
        if (codFactura.isEmpty() || fechaFactura.isEmpty() || userName.isEmpty() || usrMoto.isEmpty() || usrComprador.isEmpty() || refMoto.isEmpty()) {
            Toast.makeText(this, "Debe ingresar todos los datos", Toast.LENGTH_SHORT).show();
            jetCodVenta.requestFocus();
        } else {
            if(sw == 0) {
                url = "Http://192.168.1.15:80/WebServices/guardarFact.php";
                cap = 0;
            } else{
                url = "Http://192.168.1.15:80/WebServices/actualizarFact.php";
                cap = 1;
            }

            StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            if(cap == 0) {
                                Toast.makeText(getApplicationContext(), "Factura guardada!", Toast.LENGTH_LONG).show();
                                LimpiarMoto();
                                sw = 0;
                            }else{
                                Toast.makeText(getApplicationContext(), "Factura actualizada!", Toast.LENGTH_LONG).show();
                                LimpiarMoto();
                                sw = 0;
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            if ( cap == 0) {
                                Toast.makeText(getApplicationContext(), "Error guardando factura!", Toast.LENGTH_LONG).show();
                            }else{
                                Toast.makeText(getApplicationContext(), "Error actualizando factura!", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("codfactura", codFactura);
                    params.put("fechafactura", fechaFactura);
                    params.put("codusr", userName);
                    params.put("nameusrfactura", usrMoto);
                    params.put("comprador", usrComprador);
                    params.put("moto", moto);
                    params.put("refmoto", refMoto);
                    params.put("descmoto", descMoto);
                    params.put("valormoto", valorMoto);
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(postRequest);
        }
    }

    /*Boton Consultar Factura Completa*/
    public void ConsultarFactura(View view){
        codFactura = jetCodVenta.getText().toString().trim();
        if (codFactura.isEmpty()){
            Toast.makeText(this, "Es necesario ingresar un código de factura", Toast.LENGTH_SHORT).show();
            jetCodVenta.requestFocus();
        }else{
            url = "Http://192.168.1.15:80/WebServices/consultaCodFact.php?codfactura="+codFactura;
        }

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                sw = 1;
                Toast.makeText(VentasActivity.this, "Factura en existencia", Toast.LENGTH_SHORT).show();
                JSONObject jsonObject;
                try {
                    jsonObject = response.getJSONObject(0);//posicion 0 del arreglo....
                    jetFechaVenta.setText(jsonObject.optString("fechafactura"));
                    jetUsuarioVenta.setText(jsonObject.optString("codusr"));
                    jetNombreUsrVenta.setText(jsonObject.optString("nameusrfactura"));
                    jetNombreComprador.setText(jsonObject.optString("comprador"));
                    jtvRefMoto.setText(jsonObject.optString("refmoto"));
                    jtvDescMoto.setText(jsonObject.optString("descmoto"));
                    jtvValorMoto.setText(jsonObject.optString("valormoto"));
                    jcbActivoVenta.setChecked(jsonObject.optString("estado").equals("si"));
                    refMoto = jtvRefMoto.getText().toString();
                    jtvSeleccionMoto.setText(jsonObject.optString("moto") + " Facturada");
                    menuMotos.setEnabled(false);
                    btngomoto.setEnabled(false);
                    btnBuscarFactura.setEnabled(false);
                    jetCodVenta.setEnabled(false);
                    switch (refMoto){
                        case "HCB150R CEM_15":
                            imgPortada.setImageResource(R.drawable.honda_cb150r);
                            menuMotos.setSelection(1);
                            break;

                        case "HCB300R CEM_30":
                            imgPortada.setImageResource(R.drawable.honda_cb300r);
                            menuMotos.setSelection(2);
                            break;

                        case "HCB650R CEM_65":
                            imgPortada.setImageResource(R.drawable.honda_cb650r);
                            menuMotos.setSelection(3);
                            break;

                        case "HCB1000R CEM_100":
                            imgPortada.setImageResource(R.drawable.honda_cb1000r);
                            menuMotos.setSelection(4);
                            break;
                    }
                }
                catch (JSONException e)
                {
                    Toast.makeText(VentasActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(VentasActivity.this, "No existe factura con ese código", Toast.LENGTH_SHORT).show();
                sw = 0;
            }
        }
        );
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    /*Boton Anular Factura*/
    public void AnularFactura(View view) {
        if (sw == 0) {
            Toast.makeText(this, "Para anular primero debe realizar una consulta", Toast.LENGTH_SHORT).show();
            jetCodVenta.requestFocus();
        } else {
            url = "Http://192.168.1.15:80/WebServices/anularFact.php";
            sw = 0;


            StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            LimpiarMoto();
                            Toast.makeText(getApplicationContext(), "Factura anulada!", Toast.LENGTH_LONG).show();
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), "Error anulando facturando!", Toast.LENGTH_LONG).show();
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("codfactura", jetCodVenta.getText().toString().trim());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(postRequest);
        }
    }

    /*Boton Limipiar Campos Factura*/
    public void LimpiarFactura(View view){
        LimpiarMoto();
    }

    /*Boton Regresar al Menu Inicial*/
    public void RegresarMoto(View view){
        Intent intmain =new Intent(this,MainActivity.class);
        startActivity(intmain);
    }

    /*Evento Privado para limpiar campos de factura*/
    private void LimpiarMoto(){
        imgPortada.setImageResource(R.drawable.motorbike_animated);
        menuMotos.setSelection(0);
        jetCodVenta.setText("");
        jetUsuarioVenta.setText("");
        jetFechaVenta.setText("");
        jetNombreUsrVenta.setText("");
        jetNombreComprador.setText("");
        jtvRefMoto.setText("");
        jtvDescMoto.setText("");
        jtvValorMoto.setText("");
        jcbActivoVenta.setChecked(false);
        jtvSeleccionMoto.setText("Escoja la motocicleta Honda:");
        jetCodVenta.requestFocus();
        menuMotos.setEnabled(true);
        btngomoto.setEnabled(true);
        btnBuscarFactura.setEnabled(true);
        jetCodVenta.setEnabled(true);
        sw = 0;
        cap = 0;
    }


    @Override
    public void onErrorResponse(VolleyError error) {

    }

    @Override
    public void onResponse(JSONObject response) {

    }



}